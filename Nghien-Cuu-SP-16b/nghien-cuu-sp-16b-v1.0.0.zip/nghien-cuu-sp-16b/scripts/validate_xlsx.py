"""Validate QT16 output structure; requires openpyxl. Never edits the workbook."""
import sys,json,re,unicodedata
from openpyxl import load_workbook
def validate(file):
    wb=load_workbook(file,data_only=False)
    errors=[];seen=set();counts={}
    if wb.sheetnames!=['Trong chủ đề','Ngoài chủ đề']:errors.append('Expected exactly Trong chủ đề and Ngoài chủ đề')
    for ws in wb.worksheets:
        if ws.sheet_state!='visible':errors.append('Hidden sheet: '+ws.title)
        if ws.max_column!=2:errors.append('Expected 2 columns: '+ws.title)
        rows=list(ws.values)
        if not rows or list(rows[0])!=['Từ khóa','Volume']:errors.append('Invalid header: '+ws.title)
        counts[ws.title]=max(0,len(rows)-1)
        for n,row in enumerate(rows[1:],2):
            if len(row)!=2:continue
            k,v=row
            if not isinstance(k,str) or not k.strip():errors.append(f'Invalid keyword {ws.title}:{n}');continue
            norm=re.sub(r'\s+',' ',unicodedata.normalize('NFC',k).strip()).casefold()
            if norm in seen:errors.append(f'Duplicate keyword {ws.title}:{n}')
            seen.add(norm)
            if k.startswith('='):errors.append(f'Formula keyword {ws.title}:{n}')
            if v is not None and (isinstance(v,bool) or not isinstance(v,(int,float)) or v<0):errors.append(f'Invalid Volume {ws.title}:{n}')
    wb.close()
    return {'errors':errors,'counts':counts,'checks':'Structure only; compare all values with source separately'}
if __name__=='__main__':
    try:result=validate(sys.argv[1])
    except Exception as exc:result={'errors':[str(exc)]}
    print(json.dumps(result,ensure_ascii=False,indent=2))
    sys.exit(1 if result['errors'] else 0)
