# Quyền sử dụng

Chủ quy trình cho phép mọi người tải về, sử dụng, sao chép và điều chỉnh gói Agent Skill này cho công việc của mình.

Quyền này chỉ áp dụng nội dung gói skill; không bao gồm dữ liệu, tài liệu hoặc phần mềm của các dịch vụ bên ngoài. Các dịch vụ Google Ads và KeywordTool.io giữ điều khoản riêng. Không cung cấp tài khoản hoặc quyền truy cập nguồn kèm theo.
