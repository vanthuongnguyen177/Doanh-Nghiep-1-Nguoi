# Nghiên cứu sp 16b — phiên bản 1.0.0

Skill nghiên cứu từ khóa theo QT16. Tên kỹ thuật: nghien-cuu-sp-16b. Chữ sp trong tên hiển thị do người dùng chọn; chức năng là nghiên cứu từ khóa, không phải tìm sản phẩm/nguồn hàng.

## Cách gọi

“Dùng Nghiên cứu sp 16b nghiên cứu từ khóa kệ sách, thị trường Việt Nam, tiếng Việt. Làm xuyên suốt và giao Excel 2 tab.”

“Dùng QT16 tiếp tục từ nhật ký đã có; chỉ tra phần còn thiếu.”

## Trong gói

- [SKILL.md](SKILL.md): logic điều phối và điều kiện đạt.
- [Quy trình đầy đủ](references/quy-trinh-qt16.md): 16 bước và phần tối ưu hạn mức.
- [Kiểm tra Excel](scripts/validate_xlsx.py): cấu trúc, số liệu và từ trùng.
- [Dữ liệu giả](examples/demo.json): phục vụ thử script, không phải nghiên cứu thị trường.
- [Kết quả kiểm tra](VALIDATION.md): phần đã thử và giới hạn.
- [Giấy phép](LICENSE.md): quyền chia sẻ bản đóng gói.

## Cài và dùng

Giải nén ZIP, giữ nguyên thư mục nghien-cuu-sp-16b. Nhập hoặc đặt thư mục theo hướng dẫn Agent Skills của nền tảng đang dùng. Không có một đường dẫn cài chung cho mọi nền tảng. Nếu nền tảng chỉ đọc tệp, cung cấp SKILL.md và các tài liệu tham chiếu; việc đọc tệp không bảo đảm cơ chế tự kích hoạt skill.

Gói này được chia sẻ công khai trong kho Doanh-Nghiep-1-Nguoi, mục Nghien-Cuu-SP-16b. Việc tải gói không tự cài vào danh sách skill cá nhân.

## Phụ thuộc

Cần quyền đọc nguồn Google Ads Keyword Planner/KeywordTool.io hoặc dữ liệu xuất phù hợp. Giới hạn miễn phí có thể làm thiếu Volume. Không tự mua gói. Nền tảng phải có khả năng tạo .xlsx hoặc dùng công cụ bảng tính được hỗ trợ.

Script kiểm tra tùy chọn cần Python 3 và openpyxl có sẵn. Chạy: python scripts/validate_xlsx.py ket_qua.xlsx. Không tự cài thư viện khi chưa được phép. Nếu không chạy được script, dùng công cụ bảng tính tương đương và báo phương pháp đã dùng.

## Giới hạn

Kiểm tra cấu trúc không chứng minh phân loại ngữ nghĩa chính xác hoặc dữ liệu đầy đủ. Chưa thử trực tiếp khả năng tự nhận diện trên mọi nền tảng AI. Không đính kèm tài khoản, khóa, hội thoại riêng hay dữ liệu nghiên cứu thật.

Đối chiếu cấu trúc với [Agent Skills specification](https://agentskills.io/specification) ngày 17/11/2026; không phải chứng nhận của tổ chức đó.
