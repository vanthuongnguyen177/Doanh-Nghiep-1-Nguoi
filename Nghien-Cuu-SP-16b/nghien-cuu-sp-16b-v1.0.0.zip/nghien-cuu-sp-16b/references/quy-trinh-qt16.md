# Quy trình nghiên cứu từ khóa 16 bước (QT16)

Quy trình QT16, tích hợp yêu cầu thực hiện liên tục và bản tối ưu ngày 17/11/2026.

## Cách thực hiện

- Làm liền mạch từ bước 1 đến bước 16, tự kiểm tra giữa các bước, trả kết quả cuối cùng bằng **file Excel (.xlsx) tải về được**. Google Sheets có thể dùng để làm việc nhưng không thay thế file Excel cuối cùng. Nếu hướng dẫn công cụ mặc định ưu tiên Google Sheets, yêu cầu định dạng .xlsx rõ ràng này được ưu tiên.
- Không yêu cầu người dùng gõ “tiếp tục”, không dừng xin duyệt từng bước. Vẫn cập nhật tiến độ ngắn gọn. Chỉ hỏi khi thiếu thông tin thiết yếu không thể suy ra từ chỉ dẫn hoặc dữ liệu, gặp giới hạn cần người dùng xử lý, hay hành động vượt phạm vi đã cho phép. Không tự mua gói, trả phí hoặc cấp quyền mới.
- Dùng chủ đề, thị trường, ngôn ngữ, kỳ đo và tài khoản đúng với từng yêu cầu. Tái dùng thông tin đã chốt; không tự biến số liệu hoặc cài đặt của đợt cũ thành mặc định chung.
- Nghiên cứu từ khóa độc lập với chia nhóm SEO. QT16 kết thúc sau phân loại ý định, kiểm tra và xuất Excel; không tự chia cụm, chọn nhóm chính/phụ/bổ trợ, tạo topical map, lập URL hoặc liên kết nội bộ. Chỉ làm quy trình chia nhóm khi được yêu cầu riêng.

## 16 bước chuẩn

| Bước | Công việc | Kết quả cần có |
|---|---|---|
| 1 | Xác định phạm vi nghiên cứu | Sản phẩm/chủ đề, thị trường, ngôn ngữ, nhánh giữ/loại, mục tiêu sử dụng. |
| 2 | Kiểm tra dữ liệu đầu vào | Danh sách cũ, Volume cũ và nguồn/kỳ đo; website nếu có; xác định phần dữ liệu còn thiếu. |
| 3 | Mở rộng danh sách chủ đề seed | Danh sách từ khóa/chủ đề đầu vào phủ các công năng, chủng loại và thuộc tính liên quan. Không áp số lượng seed cố định. |
| 4 | Kiểm tra kết nối Google Ads Keyword Planner | Xác minh truy cập thực tế và tài khoản sử dụng; không tuyên bố đã tra khi chưa tra. |
| 5 | Chốt cài đặt nghiên cứu | Ghi tài khoản, quốc gia/vùng, ngôn ngữ, mạng tìm kiếm, kỳ đo và ngày lấy dữ liệu; dùng các thông số đã được chốt. |
| 6 | Nghiên cứu Google Ads | Tra các seed; lưu dữ liệu gốc theo seed, nhật ký, trạng thái và lỗi; gộp/loại trùng; tách Trong/Ngoài; bảo toàn Volume. |
| 7 | Tổng hợp DS-ADW | Danh sách Google Ads đã khử trùng, làm sạch theo quy tắc hiện hành, tách Trong/Ngoài và có truy vết. |
| 8 | Chọn seed để mở rộng | Chọn từ dữ liệu đã có, ưu tiên phủ đa dạng nhánh và tiềm năng mở rộng; Volume chỉ hỗ trợ, không quyết định một mình. Ghi lý do và nhánh Trong/Ngoài. |
| 9 | Kiểm tra truy cập KeywordTool.io | Xác minh công cụ khả dụng, nguồn tìm kiếm, quốc gia, ngôn ngữ, hạn mức và khả năng lấy số liệu. |
| 10 | Nghiên cứu KeywordTool.io | Tra riêng các seed được chọn; lưu kết quả gốc, nhật ký, phân trang và lỗi. Không tự điền Volume công cụ không cung cấp. |
| 11 | Kiểm toán nhật ký nghiên cứu | Đối chiếu seed đã chọn với lượt tra và kết quả thực lưu; phân biệt có kết quả, rỗng, lỗi và chưa tra; xử lý thiếu trong giới hạn cho phép. |
| 12 | Tạo DS-Key2 | Gộp/khử trùng gợi ý KeywordTool.io; tách hai danh sách Trong/Ngoài theo ý nghĩa toàn truy vấn; giữ nguồn seed. |
| 13 | Gộp DS-ADW và DS-Key2 | Hợp nhất riêng Trong/Ngoài; không cộng Volume của từ trùng. Ưu tiên Google Ads khi thông số đo tương thích; giữ xung đột và nguồn riêng khi không tương thích. |
| 14 | Làm sạch từ khóa | Loại từ tiếng Việt không dấu và lỗi chính tả chắc chắn; giữ ngoại ngữ/tên mẫu/mã hợp lệ; lưu từ bị loại và lý do; trường hợp chưa rõ giữ để rà soát. |
| 15 | Hoàn thiện DS-Final | Hai danh sách Trong/Ngoài, mỗi danh sách hai cột Từ khóa – Volume; Volume thiếu để trống, 0 giữ nguyên; truy vết và kiểm tra nằm ở bảng riêng. |
| 16 | Phân loại ý định, kiểm tra và xuất file Excel | Phân loại ý định ở bảng riêng, đối chiếu đầy đủ dữ liệu và Volume, kiểm tra file, rồi giao **Excel .xlsx cuối cùng** cùng tóm tắt ngắn các kết quả và giới hạn thực tế. |

## Quy tắc dữ liệu bắt buộc

- **Bỏ hẳn bước gán Volume mặc định 10.** Không thay ô trống hoặc số dưới 10 bằng 10. Giá trị 10 thực do nguồn cung cấp vẫn giữ nguyên. Không suy đoán hoặc dựng số liệu.
- Volume bằng 0 khác ô thiếu số liệu. Bảo toàn nguồn, kỳ đo và điều kiện đo. Không cộng lặp Volume cùng từ khóa; không tự chọn số lớn nhất khi xung đột.
- Phân biệt số dòng, số từ khóa duy nhất, số từ có Volume và tổng lượt tìm kiếm. Nhãn “có Volume” là số từ khóa có dữ liệu, không phải tổng Volume.
- Mỗi từ khóa duy nhất chỉ thuộc một trong hai danh sách Trong/Ngoài; các lượt xuất hiện theo seed nằm ở bảng truy vết. Việc nằm Ngoài chủ đề không đồng nghĩa lỗi chính tả hoặc phải xóa khỏi workbook.
- Xét ý nghĩa đầy đủ khi phân định Trong/Ngoài. Không gán nhầm “bàn chân” cơ thể thành “chân bàn” nội thất chỉ vì giống chữ. Ghi trường hợp ranh giới để kiểm tra.
- Loại trùng bằng chuẩn hóa phục vụ so sánh (Unicode, khoảng trắng, hoa/thường phù hợp), không tự sửa từ nguồn thành một từ mới. Lưu biến thể gốc khi cần truy vết.
- Lưu danh sách loại và lý do; đối chiếu đầu vào = giữ lại + loại theo từng giai đoạn, tính tới khử trùng. Không khẳng định đã phát hiện hết lỗi chính tả nếu chưa có căn cứ.
- Công cụ không truy cập được, không có Volume hoặc hết hạn mức: ghi rõ phần thiếu, không giả kết quả và không tự đổi nguồn rồi coi là cùng số liệu. Tận dụng dữ liệu hợp lệ sẵn có và báo giới hạn trong tin nhắn giao file và dữ liệu làm việc riêng.

## Phân loại ý định ở bước 16

- Dùng các nhãn tiếng Việt: **Thông tin**, **Cân nhắc mua**, **Giao dịch**, **Điều hướng**; dùng **Chưa xác định** khi không đủ căn cứ.
- Đọc toàn truy vấn và ngữ cảnh. Không dùng một từ khớp đơn lẻ để quyết định: “giá sách”, “tam giác”, “bánh xe”, “bán nguyệt”, “làm việc”, “gỗ tự nhiên” không phải các dấu hiệu tương ứng của giá, bán hay tự làm.
- Các truy vấn so sánh/review thường thiên về cân nhắc; mua/đặt gia công có dấu hiệu giao dịch; cách làm/hướng dẫn thường tìm thông tin. Truy vấn “làm chân bàn” có thể tìm hướng dẫn hoặc thuê làm, nên cần ghi mức chưa chắc.
- Tên sản phẩm đơn lẻ có thể có nhiều ý định. Nếu suy luận từ câu chữ thì ghi “dự kiến/sơ bộ”, mức chắc chắn và căn cứ; không tuyên bố đã kiểm chứng Google. Chỉ ghi đã đối chiếu kết quả tìm kiếm khi thực sự thực hiện.
- Sản phẩm + thương hiệu không tự động là Điều hướng. Không ép đủ bốn nhãn khi dữ liệu không có.
- Lưu từ khóa, Volume, ý định dự kiến, mức chắc chắn, căn cứ và dòng nguồn ở bảng riêng; không làm thay cấu trúc hai cột DS-Final.

## File Excel cuối cùng

- File .xlsx cuối cùng **chỉ có đúng 2 tab**, tên **Trong chủ đề** và **Ngoài chủ đề**. Mỗi tab chỉ có **2 cột: Từ khóa – Volume**. Không thêm tab báo cáo, ý định, nguồn, nhật ký, tham số hay bảng ẩn vào file giao cuối. Đây là cấu trúc đầu ra bắt buộc của phiên bản này.
- Các bảng phân loại ý định, nguồn theo seed, nhật ký, tham số, truy vết, từ bị loại và kiểm tra chất lượng vẫn được dùng làm dữ liệu làm việc riêng; không nhúng vào Excel cuối. Khi cần báo cáo phạm vi, số lượng hoặc giới hạn quan trọng, tóm tắt ngắn trong tin nhắn giao file. Không đưa giá trị chìa khóa hoặc bí mật vào dữ liệu làm việc hoặc đầu ra.
- Giữ chữ tiếng Việt, ô số đúng kiểu, tiêu đề rõ, bộ lọc và hàng đầu cố định ở danh sách dài, độ rộng cột phù hợp. Tên file gợi ý: QT16_<chu-de>_<YYYY-MM-DD>.xlsx.
- Dùng kỹ năng spreadsheet hiện có khi tạo/kiểm tra Excel. Mở đọc lại file đã xuất, xác minh đúng 2 tab nêu trên, mỗi tab đúng 2 cột Từ khóa – Volume và không có tab ẩn; so khớp đủ từ khóa và Volume, kiểm tra ô trống/0, không trùng giữa hai danh sách; kiểm tra hình thức hiển thị trước khi giao.
- Trả đường dẫn tải file .xlsx thật đã được tạo và kiểm tra. Không chỉ đưa bảng chat hoặc liên kết Google Sheets rồi gọi là kết quả cuối.

## Bổ sung ngày 17/11/2026 — Thực hiện nhanh và tiết kiệm hạn mức

Yêu cầu của người dùng: chọn cách thực hiện nhanh nhất trong điều kiện công cụ thực tế, tiết kiệm hạn mức nhưng đầu ra vẫn đáp ứng đầy đủ QT16. Phần này bổ sung cách thực hiện; không bỏ bước, không giảm phạm vi đã chốt, không đổi quy tắc Volume hoặc cấu trúc Excel cuối.

1. **Lập kế hoạch một lần:** xác định phạm vi, các nhánh cần phủ, cấu hình nguồn, dữ liệu sẵn có và phần còn thiếu. Tận dụng thông tin đã chốt; chỉ hỏi thông tin thiết yếu chưa thể xác định.
2. **Kiểm tra dữ liệu có sẵn trước khi tra:** ghi rõ chủ đề, thị trường, ngôn ngữ, mạng tìm kiếm, kỳ đo, ngày lấy và nguồn. Chỉ dùng lại khi phù hợp với yêu cầu; dữ liệu cũ phải được ghi rõ là dữ liệu cũ. Nếu yêu cầu số liệu mới, phải tra mới; không gắn ngày hiện tại cho số liệu lịch sử hoặc trộn các kỳ không tương thích.
3. **Chọn đường truy cập ngắn nhất:** ưu tiên tích hợp/API có đúng khả năng nghiên cứu; nếu không có thì dùng Keyword Planner trên tab riêng chạy nền. Không dùng số liệu chiến dịch thay cho Volume thị trường. Kiểm tra khả năng truy cập và hạn mức một lần trước khi chạy hàng loạt.
4. **Tra cứu theo lô hợp lệ:** gộp seed độc lập trong giới hạn công cụ, ví dụ tối đa 10 seed/lượt khi Keyword Planner hỗ trợ. Lưu danh sách seed của từng lô, kết quả gốc và cấu hình. Với lô nhiều seed, chỉ ghi quan hệ nguồn ở cấp lô; không bịa rằng từng từ được sinh ra từ một seed riêng.
5. **Chọn seed thích ứng:** bắt đầu bằng seed bao quát và các nhánh khác biệt; đối chiếu kết quả rồi mở rộng phần thiếu. Không đặt số lượt tra hoặc số từ khóa cố định làm mục tiêu. Có thể bỏ lượt tra trùng hoàn toàn khi đã có kết quả tương ứng phù hợp và lưu lý do dùng lại. Không bỏ nhánh chỉ vì Volume thấp hoặc thiếu.
6. **Song song có kiểm soát:** gọi đồng thời các truy vấn độc lập khi công cụ cho phép, theo nhóm nhỏ để tránh quá hạn mức. Không chạy song song các thao tác cùng thay đổi một tab, cùng file hoặc có quan hệ phụ thuộc. Việc này không đòi hỏi tạo thêm AI agent.
7. **Lấy hết kết quả của lượt tra đã chọn:** dùng xuất CSV/Excel hoặc tải dữ liệu có cấu trúc thay vì đọc từng hàng. Kiểm tra phân trang, số bản ghi, trạng thái thiếu dữ liệu và lỗi. Không coi trang đầu hoặc bản xem trước là toàn bộ dữ liệu.
8. **Lưu trạng thái ngay sau mỗi lô:** ghi khóa truy vấn gồm nguồn + seed/lô + loại gợi ý + vị trí + ngôn ngữ + mạng + kỳ đo, số kết quả và trạng thái thành công/rỗng/lỗi/chưa tra. Khi tiếp tục, chỉ chạy phần còn thiếu; chỉ thử lại lỗi có khả năng khắc phục. Không lặp vô hạn truy vấn bị chặn hoặc hết hạn mức, không tự mua gói.
9. **Xử lý bằng một luồng dữ liệu có thể lặp lại:** đọc nguồn một lần, chuẩn hóa để so sánh, khử trùng, phân định Trong/Ngoài, làm sạch và lưu truy vết bằng mã xử lý. Giữ nguyên từ nguồn trong đầu ra; lưu lý do loại riêng. Đọc toàn truy vấn với từ đa nghĩa; rà soát các trường hợp ranh giới và những lỗi quy tắc phát hiện được.
10. **Bảo toàn số liệu:** không cộng Volume trùng, không gán 10, không tự điền Volume thiếu, không thay số liệu bằng ước tính. Không trộn Volume khác thị trường/kỳ đo khi chưa có căn cứ tương thích. Giữ 0 khác ô trống. Không bỏ một từ khóa hợp lệ chỉ vì công cụ miễn phí không trả Volume.
11. **Dừng mở rộng có căn cứ:** hoàn tất các nhánh đã chốt, các lượt tra đã chọn và phân trang; đối chiếu phần bổ sung thực tế. Chỉ dừng khi nhánh còn thiếu đã được xử lý hoặc có giới hạn cụ thể được ghi nhận. Không khẳng định đã thu thập mọi từ khóa trên thị trường hoặc bảo đảm số lượt tìm kiếm.
12. **Kiểm tra một lần đầy đủ trước khi giao:** đối chiếu đầu vào = giữ lại + loại bỏ sau khi tính trùng; mỗi từ duy nhất thuộc đúng một tab; kiểm tra Volume, lỗi chính tả, phân định chủ đề và ý định sơ bộ. Đọc lại Excel xuất ra, so khớp toàn bộ từ khóa và Volume, đúng 2 tab hiển thị và 2 cột, không tab ẩn. Sau khi đạt, chỉ kiểm tra lại phần bị thay đổi hoặc có lỗi mới.
13. **Giao kết quả gọn:** file Excel cuối chỉ có Trong chủ đề / Ngoài chủ đề, mỗi tab Từ khóa / Volume; thông tin truy vết và nhật ký lưu riêng. Tin nhắn giao file nêu số lượng, kỳ đo và phần giới hạn thực tế. Cập nhật tiến độ ngắn theo mốc, không in toàn bộ dữ liệu gốc vào hội thoại.

### Điều kiện giữ chuẩn đầu ra

- Giữ đủ 16 bước về mặt công việc; có thể gộp thao tác kỹ thuật để giảm lượt gọi.
- Không giảm chất lượng bằng cách tự tạo từ khóa, bỏ phân trang, bỏ kiểm tra, giả số liệu hoặc gộp Trong/Ngoài sai nghĩa.
- Không báo đã hoàn thành đầy đủ khi còn lượt tra cần thiết bị lỗi/chưa tra; ghi rõ phạm vi hoàn tất và giới hạn còn lại.
- Các nhánh và số lượt tra của một đợt là dữ liệu thực thi, không tự biến thành định mức bắt buộc cho đợt khác.

Áp dụng phần tối ưu cho mọi đợt QT16. Quy trình chia nhóm SEO vẫn độc lập.
